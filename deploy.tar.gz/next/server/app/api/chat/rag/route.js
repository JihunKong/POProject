(()=>{var a={};a.id=431,a.ids=[431],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11997:a=>{"use strict";a.exports=require("punycode")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},25858:(a,b,c)=>{"use strict";c.d(b,{At:()=>g,jt:()=>h});var d=c(29021),e=c(33873),f=c.n(e);function g(){let a=[];try{let b=f().join(process.cwd(),"student-guide.md"),c=(0,d.readFileSync)(b,"utf-8");a.push({id:"student-guide",title:"Pure Ocean Project 학생 가이드북",content:c,metadata:{type:"guide"}});let e=f().join(process.cwd(),"student-worksheet.md"),g=(0,d.readFileSync)(e,"utf-8");a.push({id:"student-worksheet",title:"Pure Ocean Project 워크시트",content:g,metadata:{type:"worksheet"}}),a.push({id:"schedule",title:"프로젝트 일정",content:`
Pure Ocean Project 일정:
- 기간: 2025년 7월 14일(월) ~ 7월 18일(금)
- 시간: 매일 오전 9시 ~ 오후 5시
- Day 1 (7/14): 시작과 만남 - 프로젝트 소개, 팀 만들기
- Day 2 (7/15): 문제 발견 - 우리 주변 문제 탐색
- Day 3 (7/16): 해결책 찾기 - 아이디어 브레인스토밍
- Day 4 (7/17): 완성하기 - 최종 작품 완성
- Day 5 (7/18): 공유와 축하 - 발표회
      `,metadata:{type:"schedule"}}),a.push({id:"sdgs",title:"SDGs와 프로젝트",content:`
지속가능발전목표(SDGs)와 프로젝트 연계:
- SDG 1: 빈곤 종식
- SDG 2: 기아 종식
- SDG 3: 건강과 웰빙
- SDG 4: 양질의 교육
- SDG 5: 성평등
- SDG 6: 깨끗한 물과 위생
- SDG 7: 에너지
- SDG 8: 양질의 일자리와 경제성장
- SDG 9: 혁신과 인프라
- SDG 10: 불평등 감소
- SDG 11: 지속가능한 도시
- SDG 12: 책임감 있는 소비와 생산
- SDG 13: 기후 행동
- SDG 14: 해양 생태계
- SDG 15: 육상 생태계
- SDG 16: 평화와 정의
- SDG 17: 파트너십

프로젝트는 이 중 하나 이상의 SDGs와 연결되어야 합니다.
      `,metadata:{type:"sdgs"}}),a.push({id:"survey-template",title:"설문조사 템플릿",content:`
설문조사 작성 가이드:
1. 인구통계학적 질문 (나이, 성별, 거주지 등)
2. 문제 인식 관련 질문
3. 해결책에 대한 의견
4. 참여 의향
5. 추가 의견 (주관식)

질문 유형:
- 선택형 (단일/복수)
- 척도형 (1-5점, 1-10점)
- 주관식 (단답형/서술형)
      `,metadata:{type:"template"}})}catch(a){console.error("Error loading documents:",a)}return a}function h(a,b,c=3){let d=function(a,b){let c=a.toLowerCase(),d=c.split(" ").filter(a=>a.length>1);return b.map(a=>{let b=0,e=a.content.toLowerCase(),f=a.title.toLowerCase();return d.forEach(a=>{f.includes(a)&&(b+=3),e.includes(a)&&(b+=1)}),e.includes(c)&&(b+=2),{doc:a,score:b}}).filter(a=>a.score>0).sort((a,b)=>b.score-a.score).map(a=>a.doc)}(a,b),e="",f=0;for(let b of d){if(f>=c)break;let d=function(a,b=500){let c=a.split("\n"),d=[],e="";for(let a of c)e.length+a.length>b?(e&&d.push(e),e=a):e+=(e?"\n":"")+a;return e&&d.push(e),d}(b.content),g=a.toLowerCase();for(let h of d.map((b,c)=>({chunk:b,score:b.toLowerCase().includes(g)?2:+!!a.split(" ").some(a=>b.toLowerCase().includes(a.toLowerCase())),index:c})).filter(a=>a.score>0).sort((a,b)=>b.score-a.score).slice(0,c-f))e+=`

[출처: ${b.title}]
${h.chunk}`,f++}return e||"관련 문서를 찾을 수 없습니다."}},27910:a=>{"use strict";a.exports=require("stream")},28354:a=>{"use strict";a.exports=require("util")},28989:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>G,patchFetch:()=>F,routeModule:()=>B,serverHooks:()=>E,workAsyncStorage:()=>C,workUnitAsyncStorage:()=>D});var d={};c.r(d),c.d(d,{POST:()=>A});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(10641),v=c(67360),w=c(76876),x=c(96798),y=c(25858),z=c(96952);async function A(a){try{let b,c=await (0,v.j2)();if(!c?.user?.email)return u.NextResponse.json({error:"Unauthorized"},{status:401});let{message:d,conversationId:e}=await a.json();if(!d)return u.NextResponse.json({error:"Message is required"},{status:400});let f=(0,y.At)(),g=(0,y.jt)(d,f,5),h=await x.z.user.findUnique({where:{email:c.user.email}});h||(h=await x.z.user.create({data:{email:c.user.email,name:c.user.name,image:c.user.image}})),e&&(b=await x.z.conversation.findUnique({where:{id:e,userId:h.id},include:{messages:{orderBy:{createdAt:"asc"}}}})),b||(b=await x.z.conversation.create({data:{userId:h.id,title:d.slice(0,50)+"..."},include:{messages:!0}})),await x.z.message.create({data:{conversationId:b.id,role:"USER",content:d}});let i=`당신은 완도고등학교 Pure Ocean 학생들을 위한 프로젝트 도우미입니다.
    
주어진 컨텍스트를 바탕으로 학생들의 질문에 친절하고 구체적으로 답변해주세요.
프로젝트 진행에 도움이 되는 실용적인 조언을 제공하세요.

컨텍스트:
${g}

중요 지침:
1. 항상 한국어로 답변하세요
2. 학생 수준에 맞게 쉽게 설명하세요
3. 구체적인 예시를 들어주세요
4. 긍정적이고 격려하는 톤을 유지하세요
5. 컨텍스트에 없는 정보는 일반적인 지식을 바탕으로 답변하되, 추측임을 명시하세요
6. 이전 대화 내용을 고려하여 연속성 있는 답변을 제공하세요`,j=[{role:"system",content:i},...b.messages.map(a=>({role:a.role.toLowerCase(),content:a.content})),{role:"user",content:d}],k=(await w.NJ.chat.completions.create({model:w.UB,messages:j,temperature:.7,max_tokens:1e3})).choices[0].message.content||"죄송합니다. 응답을 생성할 수 없습니다.";return await x.z.message.create({data:{conversationId:b.id,role:"ASSISTANT",content:k}}),await x.z.conversation.update({where:{id:b.id},data:{updatedAt:new Date}}),u.NextResponse.json({conversationId:b.id,message:k})}catch(a){return(0,z.hS)(a)}}let B=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/chat/rag/route",pathname:"/api/chat/rag",filename:"route",bundlePath:"app/api/chat/rag/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/Users/jihunkong/POProject/src/app/api/chat/rag/route.ts",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:C,workUnitAsyncStorage:D,serverHooks:E}=B;function F(){return(0,g.patchFetch)({workAsyncStorage:C,workUnitAsyncStorage:D})}async function G(a,b,c){var d;let e="/api/chat/rag/route";"/index"===e&&(e="/");let g=await B.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:z,isOnDemandRevalidate:A,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(y.dynamicRoutes[E]||y.routes[D]);if(F&&!x){let a=!!y.routes[D],b=y.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||B.isDev||x||(G="/index"===(G=D)?"/":G);let H=!0===B.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>B.onRequestError(a,b,d,z)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>B.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&A&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await B.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})},z),b}},l=await B.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",A?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(L||b instanceof s.NoFallbackError||await B.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},29021:a=>{"use strict";a.exports=require("fs")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:a=>{"use strict";a.exports=require("path")},37830:a=>{"use strict";a.exports=require("node:stream/web")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:a=>{"use strict";a.exports=require("crypto")},55591:a=>{"use strict";a.exports=require("https")},57075:a=>{"use strict";a.exports=require("node:stream")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},67360:(a,b,c)=>{"use strict";c.d(b,{Y9:()=>g,j2:()=>h});var d=c(28516),e=c(11849),f=c(96798);let{handlers:g,auth:h,signIn:i,signOut:j}=(0,d.Ay)({trustHost:!0,debug:!0,providers:[(0,e.A)({clientId:process.env.GOOGLE_CLIENT_ID,clientSecret:process.env.GOOGLE_CLIENT_SECRET,authorization:{params:{scope:"openid email profile",prompt:"select_account"}}})],pages:{signIn:"/login",error:"/auth-error"},session:{strategy:"jwt"},callbacks:{signIn:async({user:a,account:b,profile:c})=>{if(b?.provider==="google"&&a?.email)try{return await f.z.user.upsert({where:{email:a.email},update:{name:a.name,image:a.image},create:{email:a.email,name:a.name,image:a.image,role:"STUDENT"}}),!0}catch(a){console.error("Database error during sign in:",a)}return!1},jwt:async({token:a,user:b,account:c})=>(b?.email&&(a.email=b.email),a),session:async({session:a,token:b})=>(a?.user&&b?.email&&(a.user.email=b.email),a)},secret:process.env.NEXTAUTH_SECRET})},73024:a=>{"use strict";a.exports=require("node:fs")},73566:a=>{"use strict";a.exports=require("worker_threads")},74075:a=>{"use strict";a.exports=require("zlib")},76876:(a,b,c)=>{"use strict";c.d(b,{NJ:()=>f,UB:()=>g,wT:()=>h});var d=c(76874);let e=process.env.UPSTAGE_API_KEY||"dummy-key-for-build",f=new d.Ay({apiKey:e,baseURL:"https://api.upstage.ai/v1"}),g="solar-pro2",h=`당신은 완도고등학교 Pure Ocean 학생들을 위한 GROW 코칭 모델 기반 챗봇입니다.

역할:
- GROW 모델(Goal-Reality-Options-Way forward)을 활용한 단계별 코칭
- 한 번에 하나의 질문만 제시하여 깊이 있는 사고 유도
- 학생 스스로 답을 찾도록 안내

대화 원칙:
1. 반드시 한 번에 하나의 질문만 하기
2. 답변은 2-3문장 이내로 매우 간결하게
3. 학생의 답변을 듣고 다음 단계로 진행
4. 직접적인 해답 제시 금지
5. 친근하고 격려하는 톤 유지

GROW 모델 적용:
[Goal - 목표 설정]
- "어떤 문제를 해결하고 싶나요?"
- "프로젝트의 최종 목표는 무엇인가요?"
- "성공한다면 어떤 변화가 일어날까요?"

[Reality - 현실 파악]
- "지금 상황은 어떤가요?"
- "어떤 자원을 활용할 수 있나요?"
- "가장 큰 어려움은 무엇인가요?"

[Options - 대안 탐색]
- "어떤 방법들이 가능할까요?"
- "다른 관점에서 보면 어떨까요?"
- "비슷한 성공 사례가 있을까요?"

[Way forward - 실행 계획]
- "첫 번째로 무엇을 해볼까요?"
- "언제까지 시작할 수 있을까요?"
- "도움이 필요한 부분은 무엇인가요?"

중요: 학생이 현재 어느 단계에 있는지 파악하고, 해당 단계에 맞는 질문 하나만 선택하세요.`},78335:()=>{},79551:a=>{"use strict";a.exports=require("url")},81630:a=>{"use strict";a.exports=require("http")},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},96330:a=>{"use strict";a.exports=require("@prisma/client")},96487:()=>{},96798:(a,b,c)=>{"use strict";c.d(b,{z:()=>e});var d=c(96330);let e=global.prisma||new d.PrismaClient({log:["error"]})},96952:(a,b,c)=>{"use strict";function d(a){console.error("API Error:",a);let b=a instanceof Error?a.message:"Unknown error";return"Unauthorized"===b?new Response(JSON.stringify({error:"Unauthorized"}),{status:401,headers:{"Content-Type":"application/json"}}):"Forbidden"===b?new Response(JSON.stringify({error:"Forbidden"}),{status:403,headers:{"Content-Type":"application/json"}}):new Response(JSON.stringify({error:"Internal Server Error"}),{status:500,headers:{"Content-Type":"application/json"}})}c.d(b,{hS:()=>d}),c(67360)}};var b=require("../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[586,692,988,874],()=>b(b.s=28989));module.exports=c})();