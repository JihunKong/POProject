exports.id=538,exports.ids=[538],exports.modules={25977:(a,b,c)=>{"use strict";c.d(b,{DD:()=>e,Kg:()=>n,L6:()=>m,Mx:()=>j,P9:()=>o,Q1:()=>i,VB:()=>k,YC:()=>h,ed:()=>g,zm:()=>l});var d=c(67859);let e={감상문:{description:"독서감상문, 영화감상문 등 작품에 대한 개인적 감상을 표현하는 글",structure:["도입부: 작품 소개와 첫인상","전개부: 인상 깊은 장면/내용과 개인적 감상","결론부: 작품이 주는 교훈이나 의미"],criteria:"개인적 감상의 진정성, 구체적 근거 제시, 감정 표현의 적절성"},비평문:{description:"문학작품, 예술작품 등을 객관적으로 분석하고 평가하는 글",structure:["서론: 작품 소개와 비평의 관점 제시","본론: 작품의 특징 분석과 평가","결론: 종합적 평가와 의의"],criteria:"분석의 객관성, 평가 기준의 명확성, 논리적 일관성"},보고서:{description:"조사, 실험, 관찰 등의 결과를 체계적으로 정리한 글",structure:["서론: 목적과 배경 설명","방법: 조사/실험 방법 설명","결과: 데이터와 발견사항 제시","논의: 결과 해석과 의미 분석","결론: 요약과 제언"],criteria:"객관성, 정확성, 체계성, 데이터의 신뢰성"},소논문:{description:"특정 주제에 대한 학술적 연구를 담은 글",structure:["서론: 연구 배경, 목적, 연구 문제","이론적 배경: 선행연구 검토","연구 방법: 연구 설계와 방법론","연구 결과: 분석 결과 제시","논의 및 결론: 시사점과 한계"],criteria:"학술적 엄밀성, 논리적 타당성, 독창성, 인용의 정확성"},논설문:{description:"특정 주제에 대한 주장과 논거를 제시하는 글",structure:["서론: 논제 제시와 주장 예고","본론: 논거 제시와 반박 고려","결론: 주장 강조와 설득"],criteria:"주장의 명확성, 논거의 타당성, 반박 고려, 설득력"},워크시트:{description:"Pure Ocean 프로젝트 워크시트 - 7단계 프로젝트 기획 및 실행 계획서",structure:["팀 정보: 팀명, 슬로건, 팀원 역할 분담, 팀 규칙","Step 1 문제 발견: 브레인스토밍, 문제 선정, SDGs 연결","Step 2 문제 분석: 5W1H 분석, 현황 조사, 이해관계자 분석","Step 3 해결책 개발: 아이디어 브레인스토밍, 평가, 최종 해결책, 교과 융합","Step 4 실행 계획: 필요 자원, 일정 관리(5일), 결과물 형태","Step 5 기대 효과: SMART 목표, 예상 효과, 성공 측정 방법","Step 6 발표 준비: 핵심 메시지, 발표 구성(10분), 예상 질문","Step 7 성찰: 개인 성찰, 팀 성찰, 최종 체크리스트"],criteria:"단계별 완성도, 문제의식의 구체성, SDGs 연계의 적절성, 해결책의 창의성과 실현가능성, 교과 융합의 논리성, 팀워크 계획의 체계성, 성찰의 깊이"}};function f(){try{let a=process.env.GOOGLE_SERVICE_ACCOUNT;if(!a)throw Error("GOOGLE_SERVICE_ACCOUNT 환경변수가 설정되지 않았습니다. GOOGLE_SERVICE_ACCOUNT_SETUP.md를 참조하여 설정해주세요.");let b=JSON.parse(a),c=new d.q7g.auth.GoogleAuth({credentials:b,scopes:["https://www.googleapis.com/auth/documents","https://www.googleapis.com/auth/drive","https://www.googleapis.com/auth/drive.file"]}),e=d.q7g.docs({version:"v1",auth:c}),f=d.q7g.drive({version:"v3",auth:c});return{docsService:e,driveService:f}}catch(a){throw console.error("Failed to initialize Google services:",a),a}}function g(){return f().docsService}function h(a){for(let b of[/\/document\/d\/([a-zA-Z0-9-_]+)/,/\/d\/([a-zA-Z0-9-_]+)/,/docs\.google\.com\/.*[?&]id=([a-zA-Z0-9-_]+)/,/^([a-zA-Z0-9-_]+)$/]){let c=a.match(b);if(c)return c[1]}return null}function i(a){let b=[];for(let c=0;c<a.length;c++){let d=a[c],e=d.text.trim(),f=!1,g="";for(let a of[/^(Step\s*\d+|단계\s*\d+|STEP\s*\d+)/i,/^(팀\s*정보|문제\s*발견|문제\s*분석|해결책\s*개발|실행\s*계획|기대\s*효과|발표\s*준비|성찰)/i,/^[\d]+\.\s*[가-힣A-Za-z]/,/^[가-힣A-Za-z]{2,10}:\s*/,/^(서론|본론|결론|도입부|전개부|결론부|방법|결과|논의)/i]){let b=e.match(a);if(b){f=!0,g=b[0];break}}let h=e.replace(/[\s\n\r_]+/g," ").trim(),i=h.length<20||h.includes("_______________________________")||/^[_\s]*$/.test(h);b.push({title:f?g:`섹션 ${c+1}`,start:d.start,end:d.end,text:e,type:i?"empty":f?"header":"content"})}return b}function j(a,b){let c=[...b];for(let b=0;b<c.length;b++){let d=c[b],e=a.find(a=>d.insert_at>=a.start&&d.insert_at<=a.end);e&&("empty"===e.type?d.insert_at=e.start:d.insert_at=e.end-1,"header"===e.type?d.type=`${e.title} - 구조 평가`:"empty"===e.type?d.type=`${e.title} - 작성 가이드`:d.type=`${e.title} - 내용 평가`)}return c}async function k(a,b){try{let c=await a.documents.get({documentId:b}),d=c.data.title||"제목 없음",e=[];for(let a of c.data.body?.content||[])if(a.paragraph){let b=[],c=a.startIndex||0,d=a.endIndex||0;for(let c of a.paragraph.elements||[])if(c.textRun?.content){let a=c.textRun.content;a.trim()&&b.push(a)}if(b.length>0){let a=b.join("");e.push({text:a,start:c,end:d})}}return{title:d,contentWithPositions:e}}catch(a){throw console.error("Error reading document:",a),a}}async function l(a){try{let{driveService:b}=f(),c=await b.files.get({fileId:a,fields:"version,modifiedTime"}),d=c.data.version||"1",e=c.data.modifiedTime||new Date().toISOString();return`${d}-${e}`}catch(a){throw console.error("Error getting document revision:",a),a}}async function m(a){try{let{driveService:b}=f(),c=await b.comments.list({fileId:a,fields:"comments"});return c.data.comments?.length||0}catch(a){return console.error("Error getting document comments count:",a),0}}async function n(a,b,c,d=3e5){let e=Date.now();for(;Date.now()-e<d;)try{let d=await l(a),e=await m(a);if(d!==b||e>c)return{changed:!0,finalRevision:d,finalCommentsCount:e,changeDetectedAt:new Date};await new Promise(a=>setTimeout(a,5e3))}catch(a){console.error("Error during change detection:",a),await new Promise(a=>setTimeout(a,5e3))}return{changed:!1,finalRevision:await l(a).catch(()=>b),finalCommentsCount:await m(a).catch(()=>c)}}async function o(a,b,c){return p(a,b,c)}async function p(a,b,c){try{let d=[];for(let a of[...c].sort((a,b)=>b.insert_at-a.insert_at)){let b=a.content.replace(/\*\*([^*]+)\*\*/g,"$1").replace(/\*([^*]+)\*/g,"$1").replace(/`([^`]+)`/g,"$1").replace(/^#+\s+(.+)$/gm,"$1:").replace(/\[([^\]]+)\]\([^)]+\)/g,"$1").replace(/^###\s+(.+)$/gm,"■ $1").replace(/^##\s+(.+)$/gm,"◆ $1"),c=`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`,e=`[AI 평가 - ${a.type}]
`,f=`${b}
`,g=`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

`,h=c+e+f+g;d.push({insertText:{location:{index:a.insert_at},text:h}});let i=h.length;d.push({updateTextStyle:{range:{startIndex:a.insert_at,endIndex:a.insert_at+i},textStyle:{backgroundColor:{color:{rgbColor:{red:.94,green:.97,blue:1}}}},fields:"backgroundColor"}});let j=c.length+e.length;d.push({updateTextStyle:{range:{startIndex:a.insert_at,endIndex:a.insert_at+j},textStyle:{foregroundColor:{color:{rgbColor:{red:0,green:.3,blue:.8}}},bold:!0,fontSize:{magnitude:11,unit:"PT"}},fields:"foregroundColor,bold,fontSize"}});let k=a.insert_at+j,l=f.length;d.push({updateTextStyle:{range:{startIndex:k,endIndex:k+l},textStyle:{foregroundColor:{color:{rgbColor:{red:.1,green:.1,blue:.1}}},italic:!0,fontSize:{magnitude:10,unit:"PT"}},fields:"foregroundColor,italic,fontSize"}})}if(d.length>0)return await a.documents.batchUpdate({documentId:b,requestBody:{requests:d}}),!0;return!1}catch(a){throw console.error("Error inserting inline feedback:",a),a}}},29581:(a,b,c)=>{"use strict";c.d(b,{K:()=>g});var d=c(96798),e=c(25977),f=c(76876);class g{static async createJob(a,b,c){let f=(0,e.YC)(b);if(!f)throw Error("Invalid Google Docs URL");let h=g.calculateEstimatedTime(c);return await d.z.documentFeedbackJob.create({data:{userId:a,documentId:f,documentUrl:b,genre:c,estimatedTime:h,stepDetails:{documentAccess:"pending",contentAnalysis:"pending",feedbackGeneration:"pending",documentUpdate:"pending"},currentStep:"작업 준비 중"}})}static async updateJobStatus(a,b){let c=await d.z.documentFeedbackJob.findUnique({where:{id:a}});if(!c)throw Error("Job not found");let e=c.stepDetails;return b.stepDetails&&e&&(e={...e,...b.stepDetails}),await d.z.documentFeedbackJob.update({where:{id:a},data:{...b,stepDetails:e}})}static async getJob(a){return await d.z.documentFeedbackJob.findUnique({where:{id:a},include:{user:{select:{id:!0,name:!0,email:!0}}}})}static calculateEstimatedTime(a){return({워크시트:15,보고서:12,발표자료:10,소논문:20,논설문:8})[a]||15}static calculateRemainingTime(a){if(!a.estimatedTime)return 0;let b=Math.floor((Date.now()-a.startedAt.getTime())/6e4);return Math.max(0,Math.min(Math.floor(a.estimatedTime*(100-a.progress)/100),a.estimatedTime-b))}static async processDocument(a){let b=await g.getJob(a);if(!b)throw Error("Job not found");try{console.log(`📝 Starting background processing for job ${a}`),await g.updateJobStatus(a,{status:"PROCESSING",progress:10,currentStep:"문서 접근 권한 확인 중",stepDetails:{documentAccess:"pending"}});let c=(0,e.ed)(),d=await (0,e.zm)(b.documentId),f=await (0,e.L6)(b.documentId),{title:h,contentWithPositions:i}=await (0,e.VB)(c,b.documentId);await g.updateJobStatus(a,{progress:25,currentStep:"문서 내용 분석 중",initialRevision:d,stepDetails:{documentAccess:"completed",contentAnalysis:"pending"}});let j=i.map(a=>a.text).join("\n"),k=j.replace(/[\s\n\r_]+/g," ").trim(),l=k.length<100||k.includes("_______________________________"),m=(0,e.Q1)(i);await g.updateJobStatus(a,{progress:50,currentStep:"AI 피드백 생성 중",stepDetails:{contentAnalysis:"completed",feedbackGeneration:"pending"}});let n=await g.generateFeedbacks(b.genre,j,m,l,i);await g.updateJobStatus(a,{progress:75,currentStep:"문서에 피드백 추가 중",stepDetails:{feedbackGeneration:"completed",documentUpdate:"pending"}});let o=(0,e.Mx)(m,n);if(!await (0,e.P9)(c,b.documentId,o))throw Error("Failed to insert feedback into document");await g.updateJobStatus(a,{progress:90,currentStep:"문서 변경 확인 중",stepDetails:{documentUpdate:"completed"}}),console.log(`🔍 Detecting document changes for job ${a}`);let p=await (0,e.Kg)(b.documentId,d,f,3e5);console.log(`📊 Change detection result:`,p),await g.updateJobStatus(a,{status:"COMPLETED",progress:100,currentStep:"완료",completedAt:new Date,commentsAdded:p.finalCommentsCount-f,finalRevision:p.finalRevision,stepDetails:{documentUpdate:"completed"}}),console.log(`✅ Background processing completed for job ${a}`)}catch(b){throw console.error(`❌ Background processing failed for job ${a}:`,b),await g.updateJobStatus(a,{status:"FAILED",error:b instanceof Error?b.message:"Unknown error",currentStep:"처리 실패"}),b}}static async generateFeedbacks(a,b,c,d,g){let h,i=[],j=e.DD[a];h=d?`
다음은 ${a} 템플릿입니다. 현재 대부분의 내용이 작성되지 않았습니다.

문서 내용:
${b.slice(0,3e3)}...

아직 내용이 작성되지 않았습니다. 가장 먼저 작성해야 할 부분을 1-2줄로 안내해주세요.`:`
다음은 ${a}입니다. ${a}의 일반적인 구조적 원리에 따라 평가해주세요.

평가 기준:
구조: ${j.structure.join(", ")}
초점: ${j.criteria}

문서 전체 내용:
${b.slice(0,3e3)}...

위 ${a}에 대해 가장 중요한 개선점 한 가지를 1-2줄로 간단명료하게 제시해주세요.`;let k=`당신은 완도고등학교 프로젝트의 전문 멘토입니다. 
          
역할:
- 2학년 학생들의 다양한 주제 프로젝트 워크시트 검토
- 7단계 프로젝트 과정에 따른 체계적 피드백 제공
- SDGs(지속가능발전목표) 전체를 아우르는 융합적 사고 유도

피드백 원칙:
1. 매우 간결하게 1-2줄로 핵심만 전달
2. 가장 중요한 개선점 한 가지만 제시
3. 구체적이고 실행 가능한 제안 중심

평가 중점:
- 가장 시급한 개선사항 한 가지
- 즉시 실행 가능한 조언

중요한 형식 규칙:
- 마크다운 문법을 사용하지 마세요 (**, *, #, \` 등 사용 금지)
- 일반 텍스트로만 작성하세요
- 강조가 필요한 부분은 "강조: 내용" 형태로 작성하세요
- 목록은 "- 항목1", "- 항목2" 형태로 작성하세요
- 제목은 "■ 제목:" 형태로 작성하세요`,l=(await f.NJ.chat.completions.create({model:f.UB,messages:[{role:"system",content:k},{role:"user",content:h}],max_tokens:150,temperature:.7})).choices[0].message.content||"";g.length>0&&i.push({type:"전체 평가",content:l,insert_at:g[0].start});for(let b=0;b<c.length;b++){let d=c[b];if(d.text.trim().length>30){let b;b="empty"===d.type?`
이것은 ${a}의 "${d.title}" 섹션입니다. 현재 이 섹션은 작성되지 않았습니다.

섹션 내용:
${d.text}

이 섹션에 대해 다음과 같이 안내해주세요:
1. "${d.title}" 섹션에서 작성해야 할 핵심 내용
2. 단계별 작성 가이드라인과 예시
3. 팀원들과 협력하여 작성하는 효과적인 방법
4. 다음 단계와의 연결점

학생들이 체계적으로 이 섹션을 완성할 수 있도록 구체적인 도움을 주세요.`:`
이것은 ${a}의 "${d.title}" 섹션입니다.
${a}의 구조적 원리에 따라 이 섹션을 평가해주세요.

${a}의 구조: ${j.structure.join(", ")}

분석할 내용:
${d.text}

위 "${d.title}" 섹션에 대해 다음 관점에서 피드백을 제공해주세요:
1. 섹션 목적에 맞는 내용 구성 여부
2. 구체적인 장점 2가지
3. 개선이 필요한 부분과 구체적 방법
4. 전체 문서 흐름에서의 역할과 연결성

건설적이고 실행 가능한 조언을 해주세요.`;let c=(await f.NJ.chat.completions.create({model:f.UB,messages:[{role:"system",content:k},{role:"user",content:b}],max_tokens:600,temperature:.7})).choices[0].message.content||"",e="empty"===d.type?d.start:d.end;i.push({type:d.title,content:c,insert_at:e})}}return i}static startBackgroundProcessing(a){let b=new Promise((a,b)=>{setTimeout(()=>{b(Error("Document processing timed out after 900s"))},9e5)});Promise.race([g.processDocument(a),b]).catch(async b=>{console.error(`💥 Background processing error for job ${a}:`,b);try{await g.updateJobStatus(a,{status:"FAILED",error:b instanceof Error?b.message:String(b),currentStep:b.message?.includes("timed out")?"처리 시간 초과":"처리 중 오류 발생",completedAt:new Date}),console.log(`❌ Job ${a} marked as FAILED in database`)}catch(b){console.error(`💥 Failed to update job status for ${a}:`,b)}})}}},67360:(a,b,c)=>{"use strict";c.d(b,{Y9:()=>g,j2:()=>h});var d=c(28516),e=c(11849),f=c(96798);let{handlers:g,auth:h,signIn:i,signOut:j}=(0,d.Ay)({trustHost:!0,debug:!0,providers:[(0,e.A)({clientId:process.env.GOOGLE_CLIENT_ID,clientSecret:process.env.GOOGLE_CLIENT_SECRET,authorization:{params:{scope:"openid email profile",prompt:"select_account"}}})],pages:{signIn:"/login",error:"/auth-error"},session:{strategy:"jwt"},callbacks:{signIn:async({user:a,account:b,profile:c})=>{if(b?.provider==="google"&&a?.email)try{return await f.z.user.upsert({where:{email:a.email},update:{name:a.name,image:a.image},create:{email:a.email,name:a.name,image:a.image,role:"STUDENT"}}),!0}catch(a){console.error("Database error during sign in:",a)}return!1},jwt:async({token:a,user:b,account:c})=>(b?.email&&(a.email=b.email),a),session:async({session:a,token:b})=>(a?.user&&b?.email&&(a.user.email=b.email),a)},secret:process.env.NEXTAUTH_SECRET})},76876:(a,b,c)=>{"use strict";c.d(b,{NJ:()=>f,UB:()=>g,wT:()=>h});var d=c(76874);let e=process.env.UPSTAGE_API_KEY||"dummy-key-for-build",f=new d.Ay({apiKey:e,baseURL:"https://api.upstage.ai/v1"}),g="solar-pro2",h=`당신은 완도고등학교 Pure Ocean 학생들을 위한 GROW 코칭 모델 기반 챗봇입니다.

역할:
- GROW 모델(Goal-Reality-Options-Way forward)을 활용한 단계별 코칭
- 한 번에 하나의 질문만 제시하여 깊이 있는 사고 유도
- 학생 스스로 답을 찾도록 안내

대화 원칙:
1. 반드시 한 번에 하나의 질문만 하기
2. 답변은 2-3문장 이내로 매우 간결하게
3. 학생의 답변을 듣고 다음 단계로 진행
4. 직접적인 해답 제시 금지
5. 친근하고 격려하는 톤 유지

GROW 모델 적용:
[Goal - 목표 설정]
- "어떤 문제를 해결하고 싶나요?"
- "프로젝트의 최종 목표는 무엇인가요?"
- "성공한다면 어떤 변화가 일어날까요?"

[Reality - 현실 파악]
- "지금 상황은 어떤가요?"
- "어떤 자원을 활용할 수 있나요?"
- "가장 큰 어려움은 무엇인가요?"

[Options - 대안 탐색]
- "어떤 방법들이 가능할까요?"
- "다른 관점에서 보면 어떨까요?"
- "비슷한 성공 사례가 있을까요?"

[Way forward - 실행 계획]
- "첫 번째로 무엇을 해볼까요?"
- "언제까지 시작할 수 있을까요?"
- "도움이 필요한 부분은 무엇인가요?"

중요: 학생이 현재 어느 단계에 있는지 파악하고, 해당 단계에 맞는 질문 하나만 선택하세요.`},78335:()=>{},96487:()=>{},96798:(a,b,c)=>{"use strict";c.d(b,{z:()=>e});var d=c(96330);let e=global.prisma||new d.PrismaClient({log:["error"]})},96952:(a,b,c)=>{"use strict";function d(a){console.error("API Error:",a);let b=a instanceof Error?a.message:"Unknown error";return"Unauthorized"===b?new Response(JSON.stringify({error:"Unauthorized"}),{status:401,headers:{"Content-Type":"application/json"}}):"Forbidden"===b?new Response(JSON.stringify({error:"Forbidden"}),{status:403,headers:{"Content-Type":"application/json"}}):new Response(JSON.stringify({error:"Internal Server Error"}),{status:500,headers:{"Content-Type":"application/json"}})}c.d(b,{hS:()=>d}),c(67360)}};